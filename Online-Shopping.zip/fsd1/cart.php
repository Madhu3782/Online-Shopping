<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['product_name'];
    $price = $_POST['product_price'];

    if (!isset($_SESSION['cart'][$name])) {
        $_SESSION['cart'][$name] = [
            'name' => $name,
            'price' => $price,
            'quantity' => 1
        ];
    } else {
        $_SESSION['cart'][$name]['quantity'] += 1;
    }

    header("Location: shopping.php?added=1");
    exit();
}
?>
