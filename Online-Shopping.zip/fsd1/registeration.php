<?php
// DB credentials
$host = '127.0.0.1'; // Avoids issues with 'localhost' socket
$user = 'root';
$pass = '';
$db = 'shopping_db';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("<script>alert('Database connection failed: " . $conn->connect_error . "'); 
    window.location.href = 'registration.html';</script>");
}

// Validate and sanitize input
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Basic input validation
    if (empty($name) || empty($email) || empty($password)) {
        echo "<script>alert('All fields are required.');
        window.location.href = 'registration.html';</script>";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format.');
        window.location.href = 'registration.html';</script>";
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and execute insert query
    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sss", $name, $email, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful! You can now log in.');
            window.location.href = 'login.html';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');
            window.location.href = 'registration.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Error preparing statement: " . $conn->error . "');
        window.location.href = 'registration.html';</script>";
    }

    $conn->close();
} else {
    echo "<script>alert('Invalid request method.');
    window.location.href = 'registration.html';</script>";
}
?>
