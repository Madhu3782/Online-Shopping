<?php
// --- Handle Form Submission ---
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Database connection
    $conn = new mysqli("localhost", "root", "", "shopping_db"); // Change DB name

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize inputs
    $name = $conn->real_escape_string($_POST['name']);
    $card_number = $conn->real_escape_string($_POST['card_number']);
    $card_expire_date = $conn->real_escape_string($_POST['card_expire_date']);
    $cvv = $conn->real_escape_string($_POST['cvv']);

    // Insert into table
    $sql = "INSERT INTO payment_details (name, card_number, card_expire_date, cvv)
            VALUES ('$name', '$card_number', '$card_expire_date', '$cvv')";

    if ($conn->query($sql) === TRUE) {
    // ✅ Redirect to checkout page after successful insert
    header("Location: checkout.php");
    exit();
} else {
    $message = "Error: " . $conn->error;
}


    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Form</title>
    <style>
        body {
            background: #f2f2f2;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 60px;
        }

        form {
            background: white;
            padding: 30px;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        input[type=text], input[type=password] {
            width: 250px;
            padding: 10px;
            margin: 10px 0;
        }

        input[type=submit] {
            padding: 10px 20px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
        }

        .msg {
            margin-top: 20px;
            font-weight: bold;
            color: green;
        }
    </style>
</head>
<body>

<h2>Enter Payment Details</h2>

<form method="post">
    <input type="text" name="name" placeholder="Name on Card" required><br>
<input type="text" name="card_number" placeholder="Card Number" maxlength="13" pattern="\d{13}" title="Enter exactly 13 digits" required
       oninput="this.value = this.value.replace(/[^0-9]/g, '');"><br>
<input type="text" name="card_expire_date" placeholder="MM/YY" maxlength="5" required
       pattern="^(0[1-9]|1[0-2])\/\d{2}$"
       title="Enter a valid expiry date in MM/YY format"
       oninput="this.value = this.value.replace(/[^0-9\/]/g, '');
                if(this.value.length === 2 && !this.value.includes('/')) this.value += '/';"><br>
<input type="password" name="cvv" placeholder="CVV" maxlength="4" pattern="\d{3,4}" title="Enter 3 or 4 digit CVV" required><br>
    <input type="submit" value="Submit Payment">
</form>

<?php if (isset($message)) echo "<div class='msg'>$message</div>"; ?>

</body>
</html>
