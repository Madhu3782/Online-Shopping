
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
        font-family:Arial,sans-serif;
        background:#e6ffe6;
        text-align:center;
        padding-top:100px;
    }
    .message{
        background:#fff;
        margin:auto;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        max-width: 500px;
    }
    .message{
        color: #28a745;
    }
    .buttons{
        margin-top: 20px;
    }
    a{
        margin:10px;
        text-decoration: none;
        padding: 10px,20px;
        background: #007bff;
        color: white;
        border-radius: 5px;
    }
    a.logout{
        background: red;
    }

    </style>
</head>
<body>
    <div class="message">
        <h2>Payment Successful</h2>
        <p>Thank you  FOr payment</p>
        <div class="buttons">
            <a href="shopping.php">Back TO Shop</a>
            <a href="logout.php" class="logout">logout</a>
        </div>
    </div>
    
</body>
</html>