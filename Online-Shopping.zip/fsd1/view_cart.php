<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart = $_SESSION['cart'];
$total = 0;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .total {
            text-align: right;
            font-weight: bold;
            font-size: 1.2em;
            margin-bottom: 20px;
        }
        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: space-between;
        }
        .actions a {
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background: #007bff;
            border: none;
            border-radius: 5px;
            font-size: 1em;
        }
        .actions a.logout {
            background: #dc3545;
        }
        .actions a.pay {
            background: #28a745;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Your Cart</h2>

    <?php if (count($cart) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price (₹)</th>
                    <th>Quantity</th>
                    <th>Subtotal (₹)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cart as $item):
                    $subtotal = $item['price'] * $item['quantity'];
                    $total += $subtotal;
                ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= number_format($item['price'], 2) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= number_format($subtotal, 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total">Total: ₹<?= number_format($total, 2) ?></div>

        <div class="actions">
            <a href="shopping.php">Continue Shopping</a>
            <a href="payment.php" class="pay">Click to Pay</a>
            <a href="logout.php" class="logout">Logout</a>
        </div>
    <?php else: ?>
        <p>Your cart is empty.</p>
        <div class="actions">
            <a href="shopping.php">Go Shopping</a>
            <a href="logout.php" class="logout">Logout</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
