<?php
session_start();

// Database connection settings
$host = 'localhost';
$db = 'shopping_db';
$user = 'root';
$pass = '';

// Connect to the database
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        echo "<script>alert('Please fill in all fields.'); window.location.href = 'login.html';</script>";
        exit();
    }

    // Prepare and execute SQL query
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // If user found
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user['email'];
                header("Location: shopping.php");
                exit();
            } else {
                echo "<script>alert('Incorrect password.'); window.location.href = 'login.html';</script>";
                exit();
            }
        } else {
            echo "<script>alert('Email not found. Please register.'); window.location.href = 'registeration.html';</script>";
            exit();
        }

        $stmt->close();
    } else {
        echo "Error preparing the statement: " . $conn->error;
    }
} else {
    header("Location: login.html");
    exit();
}

$conn->close();
?>