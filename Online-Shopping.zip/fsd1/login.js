function validateForm() {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMsg = document.getElementById("error-msg");

    if (email === "" || password === "") {
        errorMsg.textContent = "Please fill in all fields.";
        return false;
    }

    return true;
}
