<?php
session_start();

// Connect to DB
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'shopping_db';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get all products
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
$products = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
} else {
    echo "No products found.";
    exit();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Products - Shop</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
      padding: 20px;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      max-width: 1100px;
      margin: auto;
      margin-bottom: 20px;
    }
    .top-bar a {
      margin-left: 10px;
      text-decoration: none;
      color: #007BFF;
      font-weight: bold;
    }
    .product-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      max-width: 1100px;
      margin: auto;
    }
    .product-card {
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: calc(33.333% - 20px);
      padding: 15px;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 5px;
    }
    .product-info h2 {
      font-size: 1.2em;
      margin: 10px 0 5px;
    }
    .price {
      color: #007BFF;
      font-weight: bold;
      margin: 5px 0;
    }
    .description {
      font-size: 0.9em;
      color: #444;
      margin-bottom: 10px;
    }
    button {
      padding: 10px;
      background: #28a745;
      color: white;
      border: none;
      font-size: 1em;
      cursor: pointer;
      border-radius: 5px;
      width: 100%;
    }
    @media screen and (max-width: 768px) {
      .product-card {
        width: calc(50% - 20px);
      }
    }
    @media screen and (max-width: 480px) {
      .product-card {
        width: 100%;
      }
    }
  </style>
</head>
<body>

<div class="top-bar">
  <div><strong>Welcome, <?= htmlspecialchars($_SESSION['user']) ?>!</strong></div>
  <div>
    <a href="view_cart.php">View Cart</a> |
    <a href="logout.php">Logout</a>
  </div>
</div>

<div class="product-grid">
  <?php foreach ($products as $product): ?>
    <div class="product-card">
      <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
      <div class="product-info">
        <h2><?= htmlspecialchars($product['name']) ?></h2>
        <p class="price">₹<?= number_format($product['price'], 2) ?></p>
        <p class="description"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
        <form action="cart.php" method="POST">
          <input type="hidden" name="product_name" value="<?= htmlspecialchars($product['name']) ?>">
          <input type="hidden" name="product_price" value="<?= $product['price'] ?>">
          <button type="submit">Add to Cart</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if (isset($_GET['added']) && $_GET['added'] == 1): ?>
  <script>
    window.addEventListener('DOMContentLoaded', () => {
      alert('Item added to cart successfully');
    });
  </script>
<?php endif; ?>

</body>
</html>
