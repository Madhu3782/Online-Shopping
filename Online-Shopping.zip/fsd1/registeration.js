returnvalidateRegisteration()
{
    const name = document.getElementById("name").Value.trim();
    const email = document.getElementById("email").Value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMsg = document.getElementById("error-msg");

if(!name|| !email || !password)
{
    errorMsg.textContent="all fields are required";
    return false;
}
if(password.length<6)
{
    errorMsg.textContent="password must be at least 6 charaacter";
    return false;
}
return true;
}
